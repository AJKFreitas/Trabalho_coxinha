# SimuladoEnade
Projeto Feito em Spring Boot com o intuito de simular a realização do Enade

Trabalho de Faculdade, ano de 2015

Possui controle de Usuarios.
Coordenador pode cadastrar Professores e alunos,
Professores podem cadastrar Simulados, E perguntas/Respostas para esses Simulados.
O simulado pode ter mais de um tema diferente
Alunos podem Realizar os simulados e Verificar as notas.
