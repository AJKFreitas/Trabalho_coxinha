package com.anhanguera.cp;

import lombok.Getter;
import lombok.Setter;

/** Created by PauloMagno on 05/06/2015. */
@Getter
@Setter
public class LoginData {
  private String email;
  private String senha;
  private String tipo;

}
